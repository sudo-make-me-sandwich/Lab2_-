﻿using System.Text.Json.Serialization;

namespace Lab2
{
    public class CEnemyTemplate
    {
        [JsonInclude] 
        private string name;
        [JsonInclude]
        private string iconName;
        [JsonInclude]
        private int baseLife;
        [JsonInclude]
        private double lifeModifier;
        [JsonInclude]
        private int baseGold;
        [JsonInclude]
        private double goldModifier;
        [JsonInclude]
        private double spawnChance;

        public CEnemyTemplate(string Name, string IconName, int BaseLife, double LifeModifier,
                              int BaseGold, double GoldModifier, double SpawnChance)
        {
            name = Name;
            iconName = IconName;
            baseLife = BaseLife;
            lifeModifier = LifeModifier;
            baseGold = BaseGold;
            goldModifier = GoldModifier;
            spawnChance = SpawnChance;
        }

        public string getName()
        {
            return name;
        }

        public string getIconName()
        {
            return iconName;
        }

        public int getBaseLife()
        {
            return baseLife;
        }

        public double getLifeModifier()
        {
            return lifeModifier;
        }

        public int getBaseGold()
        {
            return baseGold;
        }

        public double getGoldModifier()
        {
            return goldModifier;
        }

        public double getSpawnChance()
        {
            return spawnChance;
        }
    }
}
