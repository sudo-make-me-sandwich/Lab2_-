﻿using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace Lab2
{
    public class CEnemyTemplateList
    {
        private List<CEnemyTemplate> enemies;

        public CEnemyTemplateList()
        {
            enemies = new List<CEnemyTemplate>();
        }

        public void Add(CEnemyTemplate enemy)
        {
            enemies.Add(enemy);
        }

        public void RemoveAt(int index)
        {
            if (index >= 0 && index < enemies.Count)
            {
                enemies.RemoveAt(index);
            }
        }

        public int getCount()
        {
            return enemies.Count;
        }

        public CEnemyTemplate getEnemy(int index)
        {
            return enemies[index];
        }

        public void Save(string path)
        {
            string jsonString = JsonSerializer.Serialize(enemies);
            File.WriteAllText(path, jsonString);
        }

        public void Load(string path)
        {
            string jsonFromFile = File.ReadAllText(path);
            enemies.Clear();
            JsonDocument doc = JsonDocument.Parse(jsonFromFile);
            foreach (JsonElement element in doc.RootElement.EnumerateArray())
            {
                string name = element.GetProperty("name").GetString();
                string iconName = element.GetProperty("iconName").GetString();
                int baseLife = element.GetProperty("baseLife").GetInt32();
                double lifeModifier = element.GetProperty("lifeModifier").GetDouble();
                int baseGold = element.GetProperty("baseGold").GetInt32();
                double goldModifier = element.GetProperty("goldModifier").GetDouble();
                double spawnChance = element.GetProperty("spawnChance").GetDouble();

                CEnemyTemplate enemy = new CEnemyTemplate(name, iconName, baseLife,
                                                          lifeModifier, baseGold,
                                                          goldModifier, spawnChance);
                enemies.Add(enemy);
            }
        }
    }
}
