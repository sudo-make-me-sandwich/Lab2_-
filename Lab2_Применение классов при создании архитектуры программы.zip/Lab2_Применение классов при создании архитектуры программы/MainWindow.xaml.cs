﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace Lab2
{
    public partial class MainWindow : Window
    {
        private CEnemyTemplateList enemyList;
        private CIconList iconList;
        private string selectedIconName = "";

        public MainWindow()
        {
            InitializeComponent();

            enemyList = new CEnemyTemplateList();
            iconList = new CIconList(iconCanvas, 72, 72);
            iconList.Load("\\icons");
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Point mousePosition = Mouse.GetPosition(iconCanvas);
            CIcon icon = iconList.getIconAt(mousePosition);
            if (icon != null)
            {
                selectedIconName = icon.getName();
                iconList.select(selectedIconName);
                lbIconName.Text = selectedIconName;
                ShowIconPreview(selectedIconName);
            }
        }
        private void ShowIconPreview(string name)
        {
            previewCanvas.Children.Clear();
            CIcon icon = iconList.getIconByName(name);
            if (icon == null)
            {
                return;
            }
            Rectangle rect = new Rectangle();
            rect.Width = 96;
            rect.Height = 96;
            RenderOptions.SetBitmapScalingMode(rect, BitmapScalingMode.NearestNeighbor);
            rect.Stroke = Brushes.Black;
            rect.Fill = new ImageBrush(icon.getImageSource());
            previewCanvas.Children.Add(rect);
        }
        private void RefreshEnemyList()
        {
            enemyListBox.Items.Clear();
            for (int i = 0; i < enemyList.getCount(); i++)
            {
                enemyListBox.Items.Add(enemyList.getEnemy(i).getName());
            }
        }
        private void enemyListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int index = enemyListBox.SelectedIndex;
            if (index < 0)
            {
                return;
            }
            CEnemyTemplate enemy = enemyList.getEnemy(index);
            tbName.Text = enemy.getName();
            tbBaseLife.Text = enemy.getBaseLife().ToString();
            tbLifeModifier.Text = enemy.getLifeModifier().ToString();
            tbBaseGold.Text = enemy.getBaseGold().ToString();
            tbGoldModifier.Text = enemy.getGoldModifier().ToString();
            tbSpawnChance.Text = enemy.getSpawnChance().ToString();
            lbIconName.Text = enemy.getIconName();
            selectedIconName = enemy.getIconName();
            iconList.select(selectedIconName);
            ShowIconPreview(selectedIconName);
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            string name = tbName.Text;
            if (name == "")
            {
                int number = enemyList.getCount() + 1;
                while (ContainsName("Противник " + number))
                {
                    number++;
                }
                name = "Противник " + number;
            }
            else if (ContainsName(name))
            {
                MessageBox.Show("Противник с именем «" + name + "» уже есть в списке.",
                                "Добавление противника",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            CEnemyTemplate enemy = new CEnemyTemplate(
                name,
                selectedIconName,
                ParseInt(tbBaseLife.Text, 10),
                ParseDouble(tbLifeModifier.Text, 1.0),
                ParseInt(tbBaseGold.Text, 5),
                ParseDouble(tbGoldModifier.Text, 1.0),
                ParseDouble(tbSpawnChance.Text, 0.5));

            enemyList.Add(enemy);
            RefreshEnemyList();
            enemyListBox.SelectedIndex = -1;
            ClearFields();
        }
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int index = enemyListBox.SelectedIndex;
            if (index >= 0)
            {
                enemyList.RemoveAt(index);
                RefreshEnemyList();
                enemyListBox.SelectedIndex = -1;
                ClearFields();
            }
        }
        private bool ContainsName(string name)
        {
            for (int i = 0; i < enemyList.getCount(); i++)
            {
                if (enemyList.getEnemy(i).getName() == name)
                {
                    return true;
                }
            }
            return false;
        }
        private void ClearFields()
        {
            tbName.Text = "";
            tbBaseLife.Text = "";
            tbLifeModifier.Text = "";
            tbBaseGold.Text = "";
            tbGoldModifier.Text = "";
            tbSpawnChance.Text = "";
        }
        private int ParseInt(string text, int defaultValue)
        {
            int value;
            if (int.TryParse(text, out value))
            {
                return value;
            }
            return defaultValue;
        }

        private double ParseDouble(string text, double defaultValue)
        {
            double value;
            if (double.TryParse(text, out value))
            {
                return value;
            }
            return defaultValue;
        }
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.FileName = "enemies"; 
            dlg.DefaultExt = ".json"; 
            dlg.Filter = "JSON documents (.json)|*.json"; 
            if (dlg.ShowDialog() == true)
            {
                enemyList.Save(dlg.FileName);
            }
        }

        private void btnLoad_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.FileName = "enemies"; 
            dlg.DefaultExt = ".json"; 
            dlg.Filter = "JSON documents (.json)|*.json"; 
            if (dlg.ShowDialog() == true)
            {
                enemyList.Load(dlg.FileName);
                RefreshEnemyList();
            }
        }
    }
}
